/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'ar', {
	title: 'خصائص الربط الموضعي',
	toolbar: 'الربط الموضعي',
	name: 'اسم الربط الموضعي',
	invalidName: 'لا يمكن ترك الربط الموضعي فارغا و لا أن يحتوي على الرموز التالية  [, ], <, >',
	pathName: 'الربط الموضعي'
} );
