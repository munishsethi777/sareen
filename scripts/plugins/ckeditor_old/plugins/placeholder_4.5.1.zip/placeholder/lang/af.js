/**
 * @license Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'af', {
	title: 'Plekhouer eienskappe',
	toolbar: 'Plekhouer',
	name: 'Plekhouer naam',
	invalidName: 'Die plekhouer mag nie leeg wees nie, en kan geen van die volgende karakters bevat nie.  [, ], <, >',
	pathName: 'plekhouer'
} );
